package edu.trianasalesianos.edu.ejercicio03ClaseBici;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio03ClaseBiciApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio03ClaseBiciApplication.class, args);
	}

}
