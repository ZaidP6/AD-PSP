package edu.trianasalesianos.edu.ejercicio03ClaseBici;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio03ClaseBiciApplicationTests {

	@Test
	void contextLoads() {
	}

}
